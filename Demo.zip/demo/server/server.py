import database
from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import datetime

app = Flask(__name__)
CORS(app)

@app.route("/users", methods=["GET"])
def get_user():
    login = request.args.get("login")
    password = request.args.get("password")

    conn = database.open_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT * FROM Users WHERE login = ? and password = ?", 
                (login, password))
    columns = [col[0] for col in cur.description]
    user = [dict(zip(columns, row)) for row in cur.fetchall()]

    if user:
        return json.dumps(user)
    else:
        return jsonify("Пользователь не зарегистрирован")
    

@app.route("/reg", methods=["POST"])
def reg_user():
    data = request.json

    if data is not None:
        full_name = data.get("fullName")
        phone = data.get("phone")
        login = data.get("login")
        password = data.get("password")

        conn = database.open_connection()
        cur = conn.cursor()

        cur.execute("INSERT INTO Users(full_name, phone, login, password, role_id) VALUES (?, ?, ?, ?, ?)", 
                    (full_name, phone, login, password, 1))
        conn.commit()
        conn.close()

        print(login, password)

        return jsonify("Пользователь зарегистрирован")
    else:
        return jsonify("Ошибка. Некорректные данные")
        

@app.route("/role", methods=["GET"])
def get_role():
    role_id = request.args.get("role_id")

    print(role_id)

    conn = database.open_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT name FROM Roles WHERE id = ?", 
                (role_id))
    columns = [col[0] for col in cur.description]
    role = [dict(zip(columns, row)) for row in cur.fetchall()]

    if role:
        return json.dumps(role)
    else:
        return jsonify("Данной роли не существует")
    

@app.route("/createapp", methods=["POST"])
def create_app():
    data = request.json

    date_edded = datetime.date.today()
    equipment = data.get("equipment")
    problem = data.get("problem")
    description = data.get("description")
    client = data.get("client")
    status = "На рассмотрении"

    print(date_edded)
    print(data)
    print(client)

    conn = database.open_connection()
    cur = conn.cursor()

    cur.execute("INSERT INTO Applications(date_edded, equipment, problem, description, client, status) VALUES (?, ?, ?, ?, ?, ?)", 
                (date_edded, equipment, problem, description, client, status))
    conn.commit()
    conn.close()

    if data is not None:
        return jsonify("Заявка создана")
    else:
        return jsonify("Ошибка. Некорректные данные")
    

@app.route("/getapp", methods=["GET"])
def getapp():
    clientName = request.args.get("clientName")
    print(clientName)

    conn = database.open_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT * FROM Applications WHERE client = ?", 
                (clientName,))
    columns = [col[0] for col in cur.description]
    applicaction = [dict(zip(columns, row)) for row in cur.fetchall()]

    if applicaction:
        return json.dumps(applicaction)
    else:
        return jsonify("Данной заявки не существует")
    

@app.route("/admin", methods=["GET"])
def admin():
    conn = database.open_connection()
    cur = conn.cursor()
    
    cur.execute("SELECT * FROM Applications")
    columns = [col[0] for col in cur.description]
    applicactions = [dict(zip(columns, row)) for row in cur.fetchall()]

    if applicactions:
        return json.dumps(applicactions)
    else:
        return jsonify("Данной заявки не существует")
    

@app.route("/changestat", methods=["POST"])
def change_status():
    data = request.json
    print(data.get("id"))

    id = data.get("id")

    conn = database.open_connection()
    cur = conn.cursor()

    cur.execute("UPDATE Applications SET status = 'Выполнено' WHERE id = ?", 
                (id))
    conn.commit()
    conn.close()


    if data is not None:
        return jsonify("Заявка выполнена")
    else:
        return jsonify("Ошибка. Некорректные данные")


if __name__ == "__main__":
    database = database.DataBase("database.db")
    app.run(debug=True)