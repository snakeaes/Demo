import sqlite3

class DataBase:

    __path = str;

    def __init__(self, __path) -> None:
        self.__path = __path
        self.create_tables()

    def open_connection(self):
        connection = sqlite3.connect(self.__path)
        return connection
    
    def close_connection(self, conn):
        conn.close()

    def create_tables(self):
        conn = self.open_connection()
        cur = conn.cursor()
        
        cur.execute("""CREATE TABLE IF NOT EXISTS Applications(
                    id              INTEGER NOT NULL PRIMARY KEY,
                    date_edded      INTEGER NOT NULL,
                    equipment       TEXT NOT NULL,
                    problem         TEXT NOT NULL,
                    description     TEXT,
                    client          TEXT NOT NULL,
                    status          INTEGER NOT NULL
        )""")

        cur.execute("""CREATE TABLE IF NOT EXISTS Users(
                    id          INTEGER NOT NULL PRIMARY KEY,
                    full_name   TEXT NOT NULL,
                    phone       TEXT NOT NULL,
                    login       TEXT NOT NULL,
                    password    TEXT NOT NULL,
                    role_id     INTEGER NOT NULL
        )""")

        cur.execute("""CREATE TABLE IF NOT EXISTS Roles(
                    id      INTEGER NOT NULL,
                    name    INTEGER NOT NULL
        )""")
        conn.commit()
        self.close_connection(conn)