<script>
    import "$lib/css/background.css";
    import "$lib/css/button.css";
</script>

<div id="wrapper">
    <button on:click={() => {window.location.href = '/auth'}}>Авторизация</button>
    <button on:click={() => {window.location.href = '/reg'}}>Регистрация</button>
</div>
