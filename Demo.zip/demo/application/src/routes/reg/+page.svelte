<script>
    import "$lib/css/background.css";
    import "$lib/css/main.css";
    import Reg from "../../lib/components/regAuth.svelte";

    const status = "Регистрация"
    const h1Text = "Регистрация";
    const btnText = "Зарегистрироваться";
    const linkPath = "/auth"
    const linkText = "У вас уже есть аккаунт?";
</script>

<Reg {status} {h1Text} {btnText} {linkPath} {linkText}/>