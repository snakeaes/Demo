<script>
    import "$lib/css/background.css";
    import "$lib/css/main.css";
    import { CreateRequest } from "$lib/js/main.js";
</script>

<div id="wrapper">
    <div id="container">

        <h1>Создание заявки</h1>
        <input id="equipment" type="text" placeholder="Оборудование">
        <input type="text" id="problem" placeholder="Тип неисправности">
        <textarea name="description" id="description" placeholder="Описание проблемы"></textarea>
        <button on:click={CreateRequest}>Создать заявку</button>
        <button on:click={ () => {window.location.href = "/main"} }>Назад</button>
    </div>
</div>