<script>
    import Auth from "$lib/components/regAuth.svelte";

    const status = "Авторизация";
    const h1Text = "Авторизация";
    const btnText = "Войти";
    const linkPath = "/reg"
    const linkText = "У вас нет аккаунта?";

</script>

<Auth {status} {h1Text} {btnText} {linkPath} {linkText}/>
