<script>
    import "$lib/css/background.css";
    import "$lib/css/main.css";
    import { onMount } from "svelte";
    import { GetApplication } from "$lib/js/main.js";

    onMount(() => {
        GetApplication();
    })


</script>

<div id="wrapper">
    <div id="container">
        <button on:click={() => {window.location.href = "/main"} }>Вернуться обратно</button>
    </div>
</div>