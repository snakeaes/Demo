<script>
    import "$lib/css/background.css";
    import "$lib/css/main.css";
    import { GetUser, GetRole } from "$lib/js/regAuth.js";
    import { onMount } from "svelte";
    import Admin from "$lib/components/admin.svelte";
    import User from "$lib/components/user.svelte";
    let role;


    onMount(async () => {
        const user = GetUser();
        console.log(user[0].role_id);

        try {
            role = await GetRole(user[0].role_id);
            console.log(role);
        } 
        catch (error) {
            console.error("Ошибка при получении роли:", error);
        }
    });

</script>

<div id="wrapper">
    <div id="container">
        {#if role === "Пользователь"}
            <User />
        {/if}
        {#if role === "Администратор"}
            <Admin />
        {/if}
    </div>
</div>