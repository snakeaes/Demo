<script>
    import axios from "axios";
    import "$lib/css/background.css";
    import "$lib/css/main.css";
    import { onMount } from "svelte";
    import { GetAllApplication } from "$lib/js/main.js";

    onMount(() => {
        GetAllApplication()
    })

    const ChangeStatus = (e) => {
        if (e.target.closest("button")) {
            console.log("Работаем");

            let target = e.target;
            const applicationId = target.parentNode.querySelector('.app__id').textContent;
            
            axios.post("http://127.0.0.1:5000/changestat", {id: applicationId})
                .then(response => {
                    console.log(response.data)
                    target.style.backgroundColor = "#90ee90"
                })
                .catch(err => {
                    console.error(err);
                });
        }
    }

</script>

<div id="wrapper">
    <div id="container" on:click={ChangeStatus}>
        <button on:click={ () => {window.location.href = "/main"} }>Вернуться обратно</button>
        <button on:click={ () => {window.location.reload()} }>Обновить данные</button>
    </div>
</div>