<script>
    import "$lib/css/menu.css";  
    import "$lib/css/button.css";  
</script>

<div id="menu">
    <h1>Админ</h1>
    <button on:click={ () => {window.location.href = "/createApp"} }>Создать заявку</button>
    <button on:click={ () => {window.location.href = "/admin"} }>Посмотреть все заявки</button>
    <button on:click={ () => {window.location.href = "/"} }>Выйти из аккаунта</button>
</div>
