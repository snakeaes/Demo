<script>
    import "$lib/css/menu.css";

    
</script>

<div id="menu">
    <h1>Пользователь</h1>
    <button on:click={ () => {window.location.href = "/createApp"} }>Создать заявку</button>
    <button on:click={ () => {window.location.href = "/viewapp"} }>Посмотреть текущие заявки</button>
    <button on:click={ () => {window.location.href = "/"} }>Выйти из аккаунта</button>
</div>
