<script>
    import "$lib/css/background.css";
    import "$lib/css/main.css";
    import {Registration, Authorization} from "$lib/js/regAuth.js";

    export let status = "";
    export let h1Text = "";
    export let btnText = "";
    export let linkPath = ""
    export let linkText = "";
</script>

<div id="wrapper">
    
    <div id="container">

        <h1>{h1Text}</h1>

        {#if status === "Регистрация"}
            <label for="full_name">ФИО</label>
            <input id="full_name" type="Text">

            <label for="phone">Телефонный номер</label>
            <input id="phone" type="Text">

            <label for="login">Логин</label>
            <input id="login" type="login">

            <label for="password">Пароль</label>
            <input id="password" type="password">

            <button on:click={Registration}>{btnText}</button>
        {/if}

        {#if status === "Авторизация"}
            <label for="login">Логин</label>
            <input id="login" type="login">
            <label for="password">Пароль</label>
            <input id="password" type="password">

            <button on:click={Authorization}>{btnText}</button>
        {/if}
        <a href={linkPath}>{linkText}</a>
    </div>

</div>